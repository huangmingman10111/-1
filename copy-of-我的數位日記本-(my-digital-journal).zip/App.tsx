import React, { useState, useEffect } from 'react';
import Layout from './components/Layout';
import YearSelection from './views/YearSelection';
import MonthSelection from './views/MonthSelection';
import CalendarView from './views/CalendarView';
import JournalEntryView from './views/JournalEntryView';
import PhotoDumpModal from './components/PhotoDumpModal';
import { ViewState, NavigationPath, JournalEntry } from './types';
import { APP_NAME, MOCK_YEARS } from './constants';
import { generatePhotoCollage } from './services/imageService';
import { Loader2 } from 'lucide-react';

const App: React.FC = () => {
  const [view, setView] = useState<ViewState>(ViewState.YEARS);
  const [navPath, setNavPath] = useState<NavigationPath>({ year: null, month: null, day: null });
  const [entries, setEntries] = useState<Record<string, JournalEntry>>({});
  const [years, setYears] = useState<number[]>(MOCK_YEARS);
  
  // Photo Dump State
  const [dumpImage, setDumpImage] = useState<string | null>(null);
  const [isGeneratingDump, setIsGeneratingDump] = useState(false);

  // Load from local storage on mount
  useEffect(() => {
    const savedEntries = localStorage.getItem('journal_entries');
    if (savedEntries) {
      setEntries(JSON.parse(savedEntries));
    }
    const savedYears = localStorage.getItem('journal_years');
    if (savedYears) {
      setYears(JSON.parse(savedYears));
    }
  }, []);

  const handleSelectYear = (year: number) => {
    setNavPath({ ...navPath, year });
    setView(ViewState.MONTHS);
  };

  const handleAddYear = () => {
    // Logic to add next available year or purely increment based on last
    const maxYear = Math.max(...years);
    const newYear = maxYear + 1;
    const newYearsList = [...years, newYear];
    setYears(newYearsList);
    localStorage.setItem('journal_years', JSON.stringify(newYearsList));
  };

  const handleSelectMonth = (month: number) => {
    setNavPath({ ...navPath, month });
    setView(ViewState.CALENDAR);
  };

  const handleSelectDay = (day: number) => {
    setNavPath({ ...navPath, day });
    setView(ViewState.ENTRY);
  };

  const handleBack = () => {
    if (view === ViewState.ENTRY) {
      setView(ViewState.CALENDAR);
    } else if (view === ViewState.CALENDAR) {
      setView(ViewState.MONTHS);
    } else if (view === ViewState.MONTHS) {
      setView(ViewState.YEARS);
    }
  };

  const handleSaveEntry = (entry: JournalEntry) => {
    const newEntries = { ...entries, [entry.date]: entry };
    setEntries(newEntries);
    localStorage.setItem('journal_entries', JSON.stringify(newEntries));
    alert("日記已保存！");
    handleBack(); // Go back to calendar
  };

  const handleGenerateDump = async (scope: 'year' | 'month') => {
    setIsGeneratingDump(true);
    
    // Filter photos based on scope
    const allPhotos: string[] = [];
    
    Object.values(entries).forEach((entry: JournalEntry) => {
        const entryDate = new Date(entry.date);
        const matchesYear = entryDate.getFullYear() === navPath.year;
        const matchesMonth = scope === 'month' ? entryDate.getMonth() === navPath.month : true;

        if (matchesYear && matchesMonth && entry.photos.length > 0) {
            allPhotos.push(...entry.photos);
        }
    });

    if (allPhotos.length === 0) {
        alert("此區間沒有照片可以生成回憶拼圖");
        setIsGeneratingDump(false);
        return;
    }

    try {
        const collage = await generatePhotoCollage(allPhotos);
        setDumpImage(collage);
    } catch (e) {
        console.error(e);
        alert("生成失敗");
    } finally {
        setIsGeneratingDump(false);
    }
  };

  const getHeaderTitle = () => {
    switch (view) {
      case ViewState.YEARS: return APP_NAME;
      case ViewState.MONTHS: return `${navPath.year}年`;
      case ViewState.CALENDAR: return `${navPath.year}年 ${navPath.month! + 1}月`;
      case ViewState.ENTRY: return '撰寫日記';
      default: return APP_NAME;
    }
  };

  const getHeaderSubtitle = () => {
    if (view === ViewState.YEARS) return 'Select a Year';
    if (view === ViewState.MONTHS) return 'Month Collection';
    if (view === ViewState.CALENDAR) return 'Calendar View';
    if (view === ViewState.ENTRY) return 'Capture the Moment';
    return '';
  };

  const getCurrentEntry = () => {
    if (navPath.year && navPath.month !== null && navPath.day) {
      const dateKey = `${navPath.year}-${String(navPath.month + 1).padStart(2, '0')}-${String(navPath.day).padStart(2, '0')}`;
      return entries[dateKey];
    }
    return undefined;
  };

  return (
    <>
      <Layout 
        view={view} 
        onBack={handleBack} 
        title={getHeaderTitle()} 
        subtitle={getHeaderSubtitle()}
      >
        {view === ViewState.YEARS && (
          <YearSelection 
            years={years}
            onSelectYear={handleSelectYear} 
            onAddYear={handleAddYear}
          />
        )}
        
        {view === ViewState.MONTHS && navPath.year && (
          <MonthSelection 
            year={navPath.year} 
            onSelectMonth={handleSelectMonth} 
            onGenerateDump={() => handleGenerateDump('year')}
          />
        )}

        {view === ViewState.CALENDAR && navPath.year && navPath.month !== null && (
          <CalendarView 
            year={navPath.year} 
            month={navPath.month} 
            onSelectDay={handleSelectDay}
            onGenerateDump={() => handleGenerateDump('month')}
            entries={entries}
          />
        )}

        {view === ViewState.ENTRY && navPath.year && navPath.month !== null && navPath.day && (
          <JournalEntryView
            year={navPath.year}
            month={navPath.month}
            day={navPath.day}
            existingEntry={getCurrentEntry()}
            onSave={handleSaveEntry}
          />
        )}
      </Layout>

      {/* Loading Overlay */}
      {isGeneratingDump && (
        <div className="fixed inset-0 z-[70] bg-black/20 backdrop-blur-sm flex items-center justify-center">
            <div className="bg-white p-6 rounded-2xl shadow-xl flex flex-col items-center gap-3">
                <Loader2 className="animate-spin text-morandi-main" size={32} />
                <p className="text-morandi-text font-serif">正在編織美好回憶...</p>
            </div>
        </div>
      )}

      {/* Photo Dump Modal */}
      {dumpImage && (
        <PhotoDumpModal 
            imageData={dumpImage} 
            onClose={() => setDumpImage(null)} 
            title={view === ViewState.MONTHS ? `${navPath.year} 年度回憶` : `${navPath.month! + 1}月 精選瞬間`}
        />
      )}
    </>
  );
};

export default App;