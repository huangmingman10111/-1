import React from 'react';
import { ArrowLeft, Book } from 'lucide-react';
import { ViewState } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  view: ViewState;
  onBack: () => void;
  title: string;
  subtitle?: string;
}

const Layout: React.FC<LayoutProps> = ({ children, view, onBack, title, subtitle }) => {
  return (
    <div className="min-h-screen bg-morandi-base flex flex-col font-sans text-morandi-text selection:bg-morandi-main selection:text-white">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-morandi-base/90 backdrop-blur-sm border-b border-morandi-accent shadow-sm">
        <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-4">
            {view !== ViewState.YEARS && (
              <button 
                onClick={onBack}
                className="p-2 rounded-full hover:bg-morandi-accent/30 transition-colors text-morandi-main"
                aria-label="Go Back"
              >
                <ArrowLeft size={24} />
              </button>
            )}
            <div>
              <h1 className="text-xl font-bold font-serif text-morandi-text tracking-wide">
                {title}
              </h1>
              {subtitle && (
                <p className="text-xs text-morandi-secondary font-medium tracking-wider uppercase">
                  {subtitle}
                </p>
              )}
            </div>
          </div>
          
          <div className="w-10 h-10 rounded-full bg-morandi-main flex items-center justify-center text-white shadow-md">
            <Book size={20} />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-4xl mx-auto w-full p-4 md:p-6 animate-fade-in">
        {children}
      </main>

      <footer className="text-center py-6 text-morandi-secondary text-sm">
        <p>&copy; {new Date().getFullYear()} 我的數位日記本</p>
      </footer>
    </div>
  );
};

export default Layout;