import React from 'react';
import { X, Download } from 'lucide-react';

interface PhotoDumpModalProps {
  imageData: string | null;
  onClose: () => void;
  title: string;
}

const PhotoDumpModal: React.FC<PhotoDumpModalProps> = ({ imageData, onClose, title }) => {
  if (!imageData) return null;

  return (
    <div className="fixed inset-0 z-[60] bg-morandi-text/40 backdrop-blur-sm flex items-center justify-center p-4 animate-fade-in">
      <div className="bg-morandi-base rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col border border-morandi-main overflow-hidden">
        {/* Header */}
        <div className="p-4 border-b border-morandi-accent flex justify-between items-center bg-white/50">
          <h3 className="font-serif text-xl text-morandi-main font-bold">{title}</h3>
          <button onClick={onClose} className="p-2 hover:bg-morandi-accent/50 rounded-full transition-colors">
            <X size={24} className="text-morandi-secondary" />
          </button>
        </div>

        {/* Image Content */}
        <div className="flex-1 overflow-auto p-6 flex justify-center bg-morandi-accent/10">
          <img src={imageData} alt="Photo Dump" className="max-w-full rounded shadow-lg object-contain" />
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-morandi-accent bg-white/50 flex justify-end">
          <a 
            href={imageData} 
            download={`journal-dump-${Date.now()}.jpg`}
            className="flex items-center gap-2 bg-morandi-main text-white px-6 py-2 rounded-full hover:bg-morandi-main/90 transition-transform hover:scale-105 shadow-md"
          >
            <Download size={18} />
            <span>下載回憶拼圖</span>
          </a>
        </div>
      </div>
    </div>
  );
};

export default PhotoDumpModal;