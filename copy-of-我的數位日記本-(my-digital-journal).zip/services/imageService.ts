export const generatePhotoCollage = async (photos: string[]): Promise<string> => {
  if (photos.length === 0) return '';

  const COLS = Math.ceil(Math.sqrt(photos.length));
  const ROWS = Math.ceil(photos.length / COLS);
  const CELL_SIZE = 300; // px
  const PADDING = 20;
  const WIDTH = COLS * CELL_SIZE + (COLS + 1) * PADDING;
  const HEIGHT = ROWS * CELL_SIZE + (ROWS + 1) * PADDING;

  const canvas = document.createElement('canvas');
  canvas.width = WIDTH;
  canvas.height = HEIGHT;
  const ctx = canvas.getContext('2d');

  if (!ctx) throw new Error('Could not get canvas context');

  // Fill Background (Morandi Base)
  ctx.fillStyle = '#F5F5F0';
  ctx.fillRect(0, 0, WIDTH, HEIGHT);

  // Load all images
  const loadedImages = await Promise.all(
    photos.map((src) => {
      return new Promise<HTMLImageElement>((resolve, reject) => {
        const img = new Image();
        img.crossOrigin = "Anonymous";
        img.onload = () => resolve(img);
        img.onerror = reject;
        img.src = src;
      });
    })
  );

  // Draw images
  loadedImages.forEach((img, index) => {
    const col = index % COLS;
    const row = Math.floor(index / COLS);
    
    const x = PADDING + col * (CELL_SIZE + PADDING);
    const y = PADDING + row * (CELL_SIZE + PADDING);

    // Aspect Ratio Fit
    const scale = Math.min(CELL_SIZE / img.width, CELL_SIZE / img.height);
    const w = img.width * scale;
    const h = img.height * scale;
    const cx = x + (CELL_SIZE - w) / 2;
    const cy = y + (CELL_SIZE - h) / 2;

    // Shadow
    ctx.save();
    ctx.shadowColor = "rgba(142, 168, 166, 0.4)"; // Morandi Main shadow
    ctx.shadowBlur = 15;
    ctx.shadowOffsetX = 5;
    ctx.shadowOffsetY = 5;
    ctx.fillStyle = 'white';
    ctx.fillRect(cx - 5, cy - 5, w + 10, h + 10); // White border
    ctx.drawImage(img, cx, cy, w, h);
    ctx.restore();
  });

  // Add Watermark
  ctx.font = '24px "Noto Serif TC"';
  ctx.fillStyle = '#8EA8A6';
  ctx.textAlign = 'right';
  ctx.fillText('My Digital Journal • Memory Dump', WIDTH - PADDING, HEIGHT - PADDING / 2);

  return canvas.toDataURL('image/jpeg', 0.9);
};