import { WeatherData } from '../types';

// WMO Weather interpretation codes (http://www.wmo.int/pages/prog/www/IMOP/WMO306/WMO306_vI_2_2011_en.pdf)
const getWeatherCondition = (wmoCode: number): WeatherData['condition'] => {
  if (wmoCode === 0) return 'Sunny';
  if (wmoCode >= 1 && wmoCode <= 3) return 'Cloudy';
  if (wmoCode >= 45 && wmoCode <= 48) return 'Cloudy';
  if (wmoCode >= 51 && wmoCode <= 67) return 'Rainy';
  if (wmoCode >= 71 && wmoCode <= 77) return 'Rainy'; // Snow treated as rain for simplicity in this theme
  if (wmoCode >= 80 && wmoCode <= 82) return 'Rainy';
  if (wmoCode >= 95 && wmoCode <= 99) return 'Windy'; // Storms
  return 'Sunny'; // Default
};

export const fetchLocalWeather = async (): Promise<WeatherData> => {
  if (!('geolocation' in navigator)) {
    throw new Error('Geolocation not supported');
  }

  return new Promise((resolve, reject) => {
    navigator.geolocation.getCurrentPosition(async (position) => {
      try {
        const { latitude, longitude } = position.coords;
        
        // Using Open-Meteo (Free, no API key required) for real-time data
        const response = await fetch(
          `https://api.open-meteo.com/v1/forecast?latitude=${latitude}&longitude=${longitude}&current=temperature_2m,weather_code`
        );
        
        if (!response.ok) throw new Error('Weather API failed');
        
        const data = await response.json();
        const current = data.current;

        resolve({
          condition: getWeatherCondition(current.weather_code),
          temp: Math.round(current.temperature_2m),
          location: `Lat: ${latitude.toFixed(1)}, Long: ${longitude.toFixed(1)}`, // Simplified location
        });
      } catch (error) {
        console.error("Error fetching weather:", error);
        // Fallback
        resolve({
          condition: 'Sunny',
          temp: 25,
          location: '無法取得氣象',
        });
      }
    }, (error) => {
      console.error("Geolocation denied:", error);
      reject(error);
    });
  });
};