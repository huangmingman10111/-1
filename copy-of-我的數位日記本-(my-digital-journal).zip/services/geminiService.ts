import { GoogleGenAI } from "@google/genai";

const getAiClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) return null;
  return new GoogleGenAI({ apiKey });
};

export const polishDiaryEntry = async (text: string, mood: string): Promise<string> => {
  const ai = getAiClient();
  if (!ai) return "請先設定 API Key 才能使用 AI 功能。";

  try {
    const prompt = `
      我正在寫日記，目前的心情是「${mood}」。
      請幫我潤飾以下這段文字，使其更具文學感且溫暖，符合莫蘭迪色系那種平靜、柔和的氛圍。
      請保持繁體中文。
      
      日記內容：
      ${text}
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
    });

    return response.text || "AI 暫時無法回應。";
  } catch (error) {
    console.error("Gemini API Error:", error);
    return "AI 服務發生錯誤，請稍後再試。";
  }
};