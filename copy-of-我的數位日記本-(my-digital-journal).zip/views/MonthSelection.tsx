import React from 'react';
import { Camera, Image as ImageIcon } from 'lucide-react';

interface MonthSelectionProps {
  year: number;
  onSelectMonth: (month: number) => void;
  onGenerateDump: () => void;
}

const MonthSelection: React.FC<MonthSelectionProps> = ({ year, onSelectMonth, onGenerateDump }) => {
  const months = Array.from({ length: 12 }, (_, i) => i);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <div className="text-center md:text-left">
          <h2 className="text-2xl text-morandi-main font-serif">請選擇月份</h2>
          <p className="text-morandi-secondary mt-2">瀏覽 {year} 年的精彩回憶</p>
        </div>
        
        <button
          onClick={onGenerateDump}
          className="flex items-center gap-2 px-5 py-2.5 bg-white border border-morandi-accent text-morandi-main rounded-full hover:bg-morandi-accent/20 transition-all shadow-sm font-medium"
        >
          <ImageIcon size={18} />
          <span>年份回顧 (Photo Dump)</span>
        </button>
      </div>
      
      <div className="grid grid-cols-3 md:grid-cols-4 gap-4">
        {months.map((month) => (
          <button
            key={month}
            onClick={() => onSelectMonth(month)}
            className="aspect-square rounded-xl bg-white border border-morandi-accent/50 hover:border-morandi-main hover:bg-morandi-main hover:text-white transition-all duration-300 shadow-sm flex flex-col items-center justify-center group"
          >
            <span className="text-2xl font-serif font-bold mb-1">
              {month + 1}
            </span>
            <span className="text-xs opacity-60 group-hover:opacity-100 uppercase tracking-wide">
              Month
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default MonthSelection;