import React from 'react';
import { Calendar as CalendarIcon, Edit2, Image as ImageIcon } from 'lucide-react';
import { JournalEntry } from '../types';

interface CalendarViewProps {
  year: number;
  month: number;
  onSelectDay: (day: number) => void;
  onGenerateDump: () => void;
  entries: Record<string, JournalEntry>;
}

const CalendarView: React.FC<CalendarViewProps> = ({ year, month, onSelectDay, onGenerateDump, entries }) => {
  const getDaysInMonth = (y: number, m: number) => new Date(y, m + 1, 0).getDate();
  const getFirstDayOfMonth = (y: number, m: number) => new Date(y, m, 1).getDay();

  const daysInMonth = getDaysInMonth(year, month);
  const firstDay = getFirstDayOfMonth(year, month);
  const days = Array.from({ length: daysInMonth }, (_, i) => i + 1);
  const emptyDays = Array.from({ length: firstDay }, (_, i) => i);

  const getEntryForDay = (day: number) => {
    const dateKey = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    return entries[dateKey];
  };

  const weekDays = ['日', '一', '二', '三', '四', '五', '六'];

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-morandi-accent overflow-hidden">
      {/* Calendar Header */}
      <div className="bg-morandi-main/10 p-4 border-b border-morandi-accent/30 flex flex-col md:flex-row justify-between items-center gap-3">
        <h3 className="font-serif text-lg text-morandi-text font-bold flex items-center gap-2">
          <CalendarIcon size={18} className="text-morandi-main" />
          {year}年 {month + 1}月
        </h3>
        
        <div className="flex gap-2">
            <button
                onClick={onGenerateDump}
                className="text-xs flex items-center gap-1.5 bg-white px-3 py-1.5 rounded-full text-morandi-main shadow-sm border border-morandi-accent hover:bg-morandi-accent/20 transition-colors"
            >
                <ImageIcon size={14} />
                月份回顧
            </button>
            <span className="text-xs bg-white/50 px-3 py-1.5 rounded-full text-morandi-secondary border border-morandi-accent/30">
            Sync Ready
            </span>
        </div>
      </div>

      {/* Grid Header */}
      <div className="grid grid-cols-7 border-b border-morandi-accent/30 bg-morandi-base/30">
        {weekDays.map(day => (
          <div key={day} className="py-3 text-center text-sm font-medium text-morandi-secondary">
            {day}
          </div>
        ))}
      </div>

      {/* Grid Body */}
      <div className="grid grid-cols-7 auto-rows-fr">
        {emptyDays.map(i => (
          <div key={`empty-${i}`} className="h-24 md:h-32 border-b border-r border-morandi-accent/10 bg-gray-50/30" />
        ))}
        {days.map(day => {
          const entry = getEntryForDay(day);
          const hasEntry = !!entry;

          return (
            <button
              key={day}
              onClick={() => onSelectDay(day)}
              className={`
                relative h-24 md:h-32 border-b border-r border-morandi-accent/20 p-2 text-left transition-all duration-200 group
                hover:bg-morandi-main/5
              `}
            >
              <span className={`
                inline-flex items-center justify-center w-7 h-7 rounded-full text-sm font-medium
                ${hasEntry ? 'bg-morandi-main text-white shadow-md' : 'text-morandi-text group-hover:bg-morandi-accent/40'}
              `}>
                {day}
              </span>

              {hasEntry && (
                <div className="mt-2 text-xs text-morandi-text/80 line-clamp-2 md:line-clamp-3 bg-white/60 rounded p-1 backdrop-blur-sm border border-morandi-accent/20">
                   {entry.weather.condition === 'Sunny' && '☀️'}
                   {entry.weather.condition === 'Rainy' && '🌧️'}
                   {entry.weather.condition === 'Cloudy' && '☁️'}
                   {' '}{entry.content}
                </div>
              )}

              {!hasEntry && (
                <div className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 text-morandi-secondary transition-opacity">
                  <Edit2 size={14} />
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default CalendarView;