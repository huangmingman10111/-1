import React from 'react';
import { Plus } from 'lucide-react';

interface YearSelectionProps {
  years: number[];
  onSelectYear: (year: number) => void;
  onAddYear: () => void;
}

const YearSelection: React.FC<YearSelectionProps> = ({ years, onSelectYear, onAddYear }) => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-8">
      {years.map((year) => (
        <button
          key={year}
          onClick={() => onSelectYear(year)}
          className="group relative h-48 rounded-2xl bg-white border border-morandi-accent shadow-sm hover:shadow-lg hover:border-morandi-main transition-all duration-300 flex flex-col items-center justify-center overflow-hidden"
        >
          <div className="absolute inset-0 bg-morandi-main/0 group-hover:bg-morandi-main/5 transition-colors duration-300" />
          <span className="text-4xl font-serif font-bold text-morandi-main mb-2 group-hover:scale-110 transition-transform duration-300">
            {year}
          </span>
          <span className="text-sm text-morandi-secondary uppercase tracking-widest">
            Year Collection
          </span>
        </button>
      ))}

      {/* Add Year Button */}
      <button
        onClick={onAddYear}
        className="h-48 rounded-2xl border-2 border-dashed border-morandi-secondary/50 hover:border-morandi-main hover:bg-morandi-main/5 transition-all duration-300 flex flex-col items-center justify-center group"
      >
        <div className="w-12 h-12 rounded-full bg-morandi-accent/50 flex items-center justify-center mb-3 group-hover:bg-morandi-main group-hover:text-white transition-colors">
          <Plus size={24} />
        </div>
        <span className="text-morandi-secondary font-medium tracking-wide group-hover:text-morandi-main">
          新增年份
        </span>
      </button>
    </div>
  );
};

export default YearSelection;