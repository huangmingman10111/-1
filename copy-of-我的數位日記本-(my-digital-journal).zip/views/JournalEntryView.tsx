import React, { useState, useEffect, useRef } from 'react';
import { Camera, Image as ImageIcon, Save, MapPin, Loader2, X } from 'lucide-react';
import { JournalEntry, WeatherData } from '../types';
import { MOODS, WEATHER_CONFIG } from '../constants';
import { fetchLocalWeather } from '../services/weatherService';

interface JournalEntryViewProps {
  year: number;
  month: number;
  day: number;
  existingEntry?: JournalEntry;
  onSave: (entry: JournalEntry) => void;
}

const JournalEntryView: React.FC<JournalEntryViewProps> = ({ year, month, day, existingEntry, onSave }) => {
  const [content, setContent] = useState(existingEntry?.content || '');
  const [mood, setMood] = useState<string>(existingEntry?.mood || MOODS[2].type);
  const [weather, setWeather] = useState<WeatherData | null>(existingEntry?.weather || null);
  const [photos, setPhotos] = useState<string[]>(existingEntry?.photos || []);
  const [isLoadingWeather, setIsLoadingWeather] = useState(!existingEntry);
  const [showCamera, setShowCamera] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Weather and Environment initialization
  useEffect(() => {
    if (!existingEntry) {
      const initWeather = async () => {
        try {
          const data = await fetchLocalWeather();
          setWeather(data);
        } catch (e) {
          console.error("Failed to fetch weather");
        } finally {
          setIsLoadingWeather(false);
        }
      };
      initWeather();
    }
  }, [existingEntry]);

  // Handle Image Upload
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setPhotos(prev => [...prev, reader.result as string]);
      };
      reader.readAsDataURL(file);
    }
  };

  // Camera Logic
  const startCamera = async () => {
    setShowCamera(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err) {
      console.error("Camera access denied:", err);
      alert("無法存取相機");
      setShowCamera(false);
    }
  };

  const takePhoto = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const ctx = canvas.getContext('2d');
      if (ctx) {
        ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setPhotos(prev => [...prev, dataUrl]);
        stopCamera();
      }
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
    }
    setShowCamera(false);
  };

  const handleSave = () => {
    if (!weather) return;
    const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
    onSave({
      id: existingEntry?.id || Date.now().toString(),
      date: dateStr,
      content,
      mood,
      weather,
      photos
    });
  };

  // Dynamic Background based on Weather
  const weatherConfig = weather ? WEATHER_CONFIG[weather.condition] : WEATHER_CONFIG.Sunny;
  const bgClass = weather ? weatherConfig.bgClass : 'bg-white';

  return (
    <div className={`relative min-h-[80vh] rounded-3xl shadow-xl overflow-hidden transition-all duration-1000 ${bgClass}`}>
      {/* Weather Overlay / Header */}
      <div className="p-6 md:p-8 border-b border-morandi-main/10 bg-white/40 backdrop-blur-md flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-3xl font-serif text-morandi-text font-bold">
            {month + 1}月 {day}日
          </h2>
          <div className="flex items-center gap-2 text-morandi-secondary mt-1">
            {isLoadingWeather ? (
              <Loader2 className="animate-spin h-4 w-4" />
            ) : (
              <>
                <MapPin size={16} />
                <span>{weather?.location}</span>
                <span>•</span>
                <weatherConfig.icon size={16} />
                <span>{weather?.temp}°C {weatherConfig.label}</span>
              </>
            )}
          </div>
        </div>
        
        {/* Mood Selector */}
        <div className="flex gap-2 flex-wrap">
          {MOODS.map((m) => {
            const isSelected = mood === m.type;
            const Icon = m.icon;
            return (
              <button
                key={m.type}
                onClick={() => setMood(m.type)}
                className={`
                  p-2 rounded-full transition-all duration-300 flex flex-col items-center gap-1 w-12
                  ${isSelected ? 'bg-white shadow-md scale-110' : 'hover:bg-white/50 opacity-70'}
                `}
                style={{ color: isSelected ? m.color : undefined }}
                title={m.label}
              >
                <Icon size={24} />
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Content Area */}
      <div className="p-6 md:p-8 space-y-6">
        
        {/* Editor */}
        <div className="bg-white/60 backdrop-blur-sm rounded-2xl p-4 shadow-sm border border-white">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            placeholder="今天發生了什麼故事..."
            className="w-full h-64 bg-transparent border-none outline-none resize-none text-morandi-text text-lg leading-relaxed placeholder-morandi-secondary/50"
          />
          
          <div className="flex justify-between items-center mt-2 border-t border-morandi-accent/30 pt-2">
            <span className="text-xs text-morandi-secondary">{content.length} 字</span>
            {/* AI Polish button removed */}
          </div>
        </div>

        {/* Media Section */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {photos.map((photo, idx) => (
            <div key={idx} className="relative aspect-square rounded-xl overflow-hidden shadow-sm group">
              <img src={photo} alt="Memory" className="w-full h-full object-cover" />
              <button 
                onClick={() => setPhotos(prev => prev.filter((_, i) => i !== idx))}
                className="absolute top-1 right-1 bg-black/30 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X size={14} />
              </button>
            </div>
          ))}
          
          <button onClick={startCamera} className="aspect-square rounded-xl border-2 border-dashed border-morandi-accent hover:border-morandi-main hover:bg-morandi-main/5 transition-all flex flex-col items-center justify-center text-morandi-secondary gap-2">
            <Camera size={24} />
            <span className="text-xs">即時拍照</span>
          </button>
          
          <label className="aspect-square rounded-xl border-2 border-dashed border-morandi-accent hover:border-morandi-main hover:bg-morandi-main/5 transition-all flex flex-col items-center justify-center text-morandi-secondary gap-2 cursor-pointer">
            <ImageIcon size={24} />
            <span className="text-xs">上傳圖片</span>
            <input type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
          </label>
        </div>

        {/* Static Save Button Area - Moved here to prevent overlap */}
        <div className="pt-4 flex justify-end">
          <button
            onClick={handleSave}
            className="w-full md:w-auto bg-morandi-main hover:bg-morandi-main/90 text-white px-8 py-3 rounded-xl shadow-lg flex items-center justify-center gap-2 transition-transform hover:scale-105"
          >
            <Save size={20} />
            <span>保存回憶</span>
          </button>
        </div>

      </div>

      {/* Camera Modal Overlay */}
      {showCamera && (
        <div className="fixed inset-0 z-50 bg-black/90 flex flex-col items-center justify-center p-4">
          <div className="relative w-full max-w-lg aspect-[3/4] bg-black rounded-lg overflow-hidden">
             <video ref={videoRef} autoPlay playsInline muted className="w-full h-full object-cover" />
             <canvas ref={canvasRef} className="hidden" />
             
             <button onClick={stopCamera} className="absolute top-4 right-4 text-white p-2">
               <X size={32} />
             </button>
             
             <div className="absolute bottom-6 left-0 right-0 flex justify-center">
               <button onClick={takePhoto} className="w-16 h-16 rounded-full border-4 border-white flex items-center justify-center">
                 <div className="w-14 h-14 bg-white rounded-full active:scale-90 transition-transform" />
               </button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default JournalEntryView;