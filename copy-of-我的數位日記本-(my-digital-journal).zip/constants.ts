import { MoodType } from './types';
import { Sun, CloudRain, Cloud, Wind, Smile, Meh, Frown, Angry, BatteryLow, Zap } from 'lucide-react';

export const APP_NAME = "我的數位日記本";

export const MOODS = [
  { type: MoodType.HAPPY, label: '愉悅', icon: Smile, color: '#E6CBA8' },
  { type: MoodType.EXCITED, label: '期待', icon: Zap, color: '#D4A5A5' },
  { type: MoodType.CALM, label: '平靜', icon: Meh, color: '#8EA8A6' }, // Main Morandi
  { type: MoodType.TIRED, label: '疲憊', icon: BatteryLow, color: '#A8B8C0' },
  { type: MoodType.SAD, label: '憂鬱', icon: Frown, color: '#9FA4A9' },
  { type: MoodType.ANGRY, label: '煩躁', icon: Angry, color: '#B58E8E' },
];

export const WEATHER_CONFIG = {
  Sunny: { label: '晴朗', icon: Sun, bgClass: 'bg-gradient-to-br from-[#F5F5F0] to-[#E6CBA8]' },
  Rainy: { label: '雨天', icon: CloudRain, bgClass: 'bg-gradient-to-br from-[#F5F5F0] to-[#A8B8C0]' },
  Cloudy: { label: '多雲', icon: Cloud, bgClass: 'bg-gradient-to-br from-[#F5F5F0] to-[#C4D1C3]' },
  Windy: { label: '強風', icon: Wind, bgClass: 'bg-gradient-to-br from-[#F5F5F0] to-[#8EA8A6]' },
};

export const MOCK_YEARS = [2025];