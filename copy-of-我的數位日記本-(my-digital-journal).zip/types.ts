export enum ViewState {
  YEARS = 'YEARS',
  MONTHS = 'MONTHS',
  CALENDAR = 'CALENDAR',
  ENTRY = 'ENTRY'
}

export interface JournalEntry {
  id: string;
  date: string; // ISO string YYYY-MM-DD
  content: string;
  mood: string;
  weather: WeatherData;
  photos: string[]; // Base64 strings
}

export interface WeatherData {
  condition: 'Sunny' | 'Rainy' | 'Cloudy' | 'Windy';
  temp: number;
  location: string;
}

export interface NavigationPath {
  year: number | null;
  month: number | null; // 0-11
  day: number | null;
}

export enum MoodType {
  HAPPY = 'Happy',
  CALM = 'Calm',
  SAD = 'Sad',
  ANGRY = 'Angry',
  TIRED = 'Tired',
  EXCITED = 'Excited'
}